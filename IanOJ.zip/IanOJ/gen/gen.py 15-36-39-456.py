from random import randint
import math

for i in range(3, 31):
    with open(f"test_data/33/{i}.in", "w") as f:
        f.write(str(a:=randint(1, 5*10**7)) + "\n" + str(b:=randint(1, 89)))
    with open(f"test_data/33/{i}.out", "w") as f:
        f.write(str(int(round(math.sqrt((a*9.81)/math.sin(2*b*math.pi/180))))))