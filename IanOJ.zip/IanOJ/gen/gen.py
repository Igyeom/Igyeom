import random

for i in range(3, 31):
    a, b, c = random.randint(1, 10), random.randint(1, 10), random.randint(1, 10)
    with open(f"test_data/4/{i}.in", "w") as f:
        f.write(f"{a} {b} {c}")
    with open(f"test_data/4/{i}.out", "w") as f:
        f.write(f"{(a+b+c-1)**3}")