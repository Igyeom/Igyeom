from random import choice, randint

idx = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"

for i in range(3, 31):
    with open(f"test_data/18/{i}.in", "w+") as f:
        content = ""
        for _ in range(randint(1, 100)):
            content += choice("abcdefghijklmnopqrstuvwxyz ")
            f.write(content[-1])
        a = choice("abcdefghijklmnopqrstuvwxyz")
        b = choice("abcdefghijklmnopqrstuvwxyz".replace(a, ""))
        key = ord(b)-ord(a)
        f.write(f"\n{a} {b}")
    with open(f"test_data/18/{i}.out", "w") as f:
        for j in content:
            if j == " ":
                f.write(" ")
            else:
                f.write(idx[idx.index(j) + key])