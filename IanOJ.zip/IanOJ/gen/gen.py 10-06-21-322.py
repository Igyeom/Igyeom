from random import randint

for i in range(3, 51):
    with open(f"test_data/1/{i}.in", "w") as f:
        f.write(str(a:=randint(-10**9, 10**9)) + " " + str(b:=randint(-10**9, 10**9)))
    with open(f"test_data/1/{i}.out", "w") as f:
        f.write(str(a+b))