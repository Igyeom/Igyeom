from random import randint

for i in range(3, 31):
    v, n = randint(1, 2*10**8), randint(1, 2*10**8)
    with open("test_data/31/{}.in".format(i), "w") as f:
        f.write("{}\n{}".format(v, n))
    with open("test_data/31/{}.out".format(i), "w") as f:
        f.write(str(v//n))