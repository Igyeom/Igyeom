import random

for i in range(3, 31):
    s = ""
    for _ in range(random.randint(1, 1000)):
        s += random.choice(["0", "1"])
    with open(f"test_data/35/{i}.in", "w") as f:
        f.write(s)
    with open(f"test_data/35/{i}.out", "w") as f:
        ans = 0
        max_jump = 1
        cnt = 0
        last_i = False
        for i in s:
            if i == '1':
                cnt += 1
                if cnt > max_jump:
                    break
                last_i = True
            if i == '0':
                if cnt == max_jump:
                    max_jump += 1
                ans += cnt
                cnt = 0
                last_i = False
        f.write(str(ans))