from random import randint, choice

for i in range(3, 31):
    n = randint(1, 500)
    m = randint(1, n-1)

    with open(f"test_data/32/{i}" + ".in", "w") as f:
        f.write(f"{n}\n{m}\n")
        lst = [*range(1, n+1)]
        for _ in range(m):
            x = choice(lst)
            f.write(f"{x} ")
            lst.remove(x)
    with open(f"test_data/32/{i}" + ".out", "w") as f:
        f.write(str(sum(lst)))