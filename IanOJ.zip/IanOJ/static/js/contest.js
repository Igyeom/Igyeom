function convertTZ(date, tzString) {
    return new Date((typeof date === "string" ? new Date(date) : date).toLocaleString("en-US", {timeZone: tzString}));   
}

document.getElementById("start_time").innerHTML = convertTZ(new Date(parseInt(document.getElementById("schedule").innerHTML) * 1000)).toLocaleString();


let problems = document.getElementById("problems").innerHTML.split(", ");
let scoring = document.getElementById("scoring").innerHTML.split(", ");
let keys = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
let s = ""

for (let i = 0; i < problems.length; i++) {
    s += "<tr><td>" + keys[i] + "</td><td><a href='/problem/" + problems[i] + "'>Problem</a></td><td>" + scoring[i] + "</td></tr>";
}

document.getElementById("problemss").innerHTML = s;