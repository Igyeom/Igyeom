
if  (parseInt(r.innerHTML) >= 3000) {
    r.innerHTML = r.innerHTML.replaceAll("gm@", "").replaceAll("@", "") + "</a></b>";
    r.innerHTML = "<b><a style='color: red;'><span style='color: white;'>" + r.innerHTML[0] + "</span><span style='color: red;'>" + r.innerHTML.slice(1) + "</span></b>";
}
if  (parseInt(r.innerHTML) >= 2500 && parseInt(r.innerHTML) < 3000) {
    r.innerHTML = r.innerHTML.replaceAll("red@", "").replaceAll("@", "") + "</a></b>";
    r.innerHTML = "<b><a style='color: red;'>" + r.innerHTML + "</a></b>";
}
if  (parseInt(r.innerHTML) >= 2100 && parseInt(r.innerHTML) < 2500) {
    r.innerHTML = r.innerHTML.replaceAll("dia@", "").replaceAll("@", "") + "</a></b>";
    r.innerHTML = "<b><a style='color: #0dd;'>" + r.innerHTML + "</a></b>";
}
if  (parseInt(r.innerHTML) >= 1700 && parseInt(r.innerHTML) < 2100) {
    r.innerHTML = r.innerHTML.replaceAll("plat@", "").replaceAll("@", "") + "</a></b>";
    r.innerHTML = "<b><a style='color: #3dffae;'>" + r.innerHTML + "</a></b>";
}
if  (parseInt(r.innerHTML) >= 1400 && parseInt(r.innerHTML) < 1700) {
    r.innerHTML = r.innerHTML.replaceAll("gold@", "").replaceAll("@", "") + "</a></b>";
    r.innerHTML = "<b><a style='color: #cc0;''>" + r.innerHTML + "</a></b>";
}
if  (parseInt(r.innerHTML) >= 1000 && parseInt(r.innerHTML) < 1400) {
    r.innerHTML = r.innerHTML.replaceAll("silver@", "").replaceAll("@", "") + "</a></b>";
    r.innerHTML = "<b><a style='color: #fff;'>" + r.innerHTML + "</a></b>";
}
if  (parseInt(r.innerHTML) >= 800 && parseInt(r.innerHTML) < 1000) {
    r.innerHTML = r.innerHTML.replaceAll("bronze@", "").replaceAll("@", "") + "</a></b>";
    r.innerHTML = "<b><a style='color: #930;'>" + r.innerHTML + "</a></b>";
}
if  (parseInt(r.innerHTML) < 800) {
    r.innerHTML = r.innerHTML.replaceAll("unrated@", "").replaceAll("@", "") + "</a></b>";
    r.innerHTML = "<b><a style='color: #888;'>" + r.innerHTML + "</a></b>";
}