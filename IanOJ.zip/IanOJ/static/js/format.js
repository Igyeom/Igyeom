window.MathJax = {
    tex: {
      inlineMath: [['$', '$']]
    }
};


for (i of document.querySelectorAll(".rating")) {
    if  (parseInt(i.innerHTML) >= 3000) {
        i.innerHTML = i.innerHTML.replaceAll("gm@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a style='color: red;'><span style='color: white;'>" + i.innerHTML[0] + "</span><span style='color: red;'>" + i.innerHTML.slice(1) + "</span></b>";
    }
    if  (parseInt(i.innerHTML) >= 2500 && parseInt(i.innerHTML) < 3000) {
        i.innerHTML = i.innerHTML.replaceAll("red@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a style='color: red;'>" + i.innerHTML + "</a></b>";
    }
    if  (parseInt(i.innerHTML) >= 2100 && parseInt(i.innerHTML) < 2500) {
        i.innerHTML = i.innerHTML.replaceAll("dia@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a style='color: #0dd;'>" + i.innerHTML + "</a></b>";
    }
    if  (parseInt(i.innerHTML) >= 1700 && parseInt(i.innerHTML) < 2100) {
        i.innerHTML = i.innerHTML.replaceAll("plat@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a style='color: #3dffae;'>" + i.innerHTML + "</a></b>";
    }
    if  (parseInt(i.innerHTML) >= 1400 && parseInt(i.innerHTML) < 1700) {
        i.innerHTML = i.innerHTML.replaceAll("gold@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a style='color: #cc0;''>" + i.innerHTML + "</a></b>";
    }
    if  (parseInt(i.innerHTML) >= 1000 && parseInt(i.innerHTML) < 1400) {
        i.innerHTML = i.innerHTML.replaceAll("silver@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a style='color: #fff;'>" + i.innerHTML + "</a></b>";
    }
    if  (parseInt(i.innerHTML) >= 800 && parseInt(i.innerHTML) < 1000) {
        i.innerHTML = i.innerHTML.replaceAll("bronze@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a style='color: #930;'>" + i.innerHTML + "</a></b>";
    }
    if  (parseInt(i.innerHTML) < 800) {
        i.innerHTML = i.innerHTML.replaceAll("unrated@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a style='color: #888;'>" + i.innerHTML + "</a></b>";
    }
}

for (i of document.querySelectorAll(".name")) {
    if (i.innerHTML == "ian") {
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: #eb3483;'>" + i.innerHTML + "</a></b>";
        continue;
    }

    if  (i.innerHTML.includes("admin@")) {
        i.innerHTML = i.innerHTML.replaceAll("admin@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: #eb3483;'>" + i.innerHTML + "</a></b>";
    }
    if  (i.innerHTML.includes("gm@")) {
        i.innerHTML = i.innerHTML.replaceAll("gm@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: red;'><span style='color: white;'>" + i.innerHTML[0] + "</span><span style='color: red;'>" + i.innerHTML.slice(1) + "</span></b>";
    }
    if  (i.innerHTML.includes("red@")) {
        i.innerHTML = i.innerHTML.replaceAll("red@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: red;'>" + i.innerHTML + "</a></b>";
    }
    if  (i.innerHTML.includes("dia@")) {
        i.innerHTML = i.innerHTML.replaceAll("dia@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: #0dd;'>" + i.innerHTML + "</a></b>";
    }
    if  (i.innerHTML.includes("plat@")) {
        i.innerHTML = i.innerHTML.replaceAll("plat@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: #3dffae;'>" + i.innerHTML + "</a></b>";
    }
    if  (i.innerHTML.includes("gold@")) {
        i.innerHTML = i.innerHTML.replaceAll("gold@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: #cc0;'>" + i.innerHTML + "</a></b>";
    }
    if  (i.innerHTML.includes("silver@")) {
        i.innerHTML = i.innerHTML.replaceAll("silver@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: #fff;'>" + i.innerHTML + "</a></b>";
    }
    if  (i.innerHTML.includes("bronze@")) {
        i.innerHTML = i.innerHTML.replaceAll("bronze@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: #930;'>" + i.innerHTML + "</a></b>";
    }
    if  (i.innerHTML.includes("unrated@")) {
        i.innerHTML = i.innerHTML.replaceAll("unrated@", "").replaceAll("@", "") + "</a></b>";
        i.innerHTML = "<b><a href='/@" + i.innerHTML + "' style='color: #888;'>" + i.innerHTML + "</a></b>";
    }
}


document.body.innerHTML = document.body.innerHTML.replaceAll("Accepted", "<b style='color: #0d0;'>Accepted</b>");
document.body.innerHTML = document.body.innerHTML.replaceAll("Partially accepted", "<b style='color: #ff0;'>Partially Accepted</b>");
document.body.innerHTML = document.body.innerHTML.replaceAll("Wrong answer", "<b style='color: #f00;'>Wrong answer</b>");
document.body.innerHTML = document.body.innerHTML.replaceAll("Time limit exceeded", "<b style='color: #f50;'>Time limit exceeded</b>");
document.body.innerHTML = document.body.innerHTML.replaceAll("Memory limit exceeded", "<b style='color: #f50;'>Memory limit exceeded</b>");
document.body.innerHTML = document.body.innerHTML.replaceAll("Compile error", "<b style='color: #0af;'>Compile error</b>");
document.body.innerHTML = document.body.innerHTML.replaceAll("Runtime error", "<b style='color: #0af;'>Runtime error</b>");

if (document.getElementById("submittable").innerHTML == "yes") {
    document.getElementById("yes").hidden = false;
}
if (document.getElementById("submittable").innerHTML == "wip") {
    document.getElementById("wip").hidden = false;
}
if (document.getElementById("submittable").innerHTML == "wontfix") {
    document.getElementById("wontfix").hidden = false;
}

function nl2br (str, is_xhtml) {
    var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
    return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
}

for (i of document.querySelectorAll(".content")) {
    i.innerHTML = nl2br(i.innerHTML.replaceAll("\n\n", "\n"));
}