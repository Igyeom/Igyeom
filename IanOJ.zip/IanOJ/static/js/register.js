function passcheck() {
    var pass = document.getElementById("password").value;
    var cpass = document.getElementById("confirm-password").value;
    
    if (pass == cpass) {
        document.getElementById("msg").hidden = true;
        document.getElementById("submit").disabled = false;
    } else {
        document.getElementById("msg").hidden = false;
        document.getElementById("submit").disabled = true;
    }
}

setInterval(passcheck, 50);