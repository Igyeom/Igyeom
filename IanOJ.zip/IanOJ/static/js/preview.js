function preview() {
    MathJax.Hub = {
        Queue: function () {
        for (var i = 0, m = arguments.length; i < m; i++) {
            var fn = MathJax.Callback(arguments[i]);
            MathJax.startup.promise = MathJax.startup.promise.then(fn);
        }
        return MathJax.startup.promise;
        },
        Typeset: function (elements, callback) {
        var promise = MathJax.typesetPromise(elements);
        if (callback) {
            promise = promise.then(callback);
        }
        return promise;
        },
        Register: {
        MessageHook: function () {console.log('MessageHooks are not supported in version 3')},
        StartupHook: function () {console.log('StartupHooks are not supported in version 3')},
        LoadHook: function () {console.log('LoadHooks are not supported in version 3')}
        },
        Config: function () {console.log('MathJax configurations should be converted for version 3')}
    };
    
    document.getElementById("pname").innerHTML = document.getElementById("name").value;
    document.getElementById("ptime_limit").innerHTML = document.getElementById("time_limit").value;
    document.getElementById("pmemory_limit").innerHTML = document.getElementById("memory_limit").value;
    document.getElementById("pdescription").innerHTML = document.getElementById("description").value;
    document.getElementById("pinput").innerHTML = document.getElementById("input").value;
    document.getElementById("poutput").innerHTML = document.getElementById("output").value;
    document.getElementById("psample_cases").innerHTML = document.getElementById("sample_cases").value;
    document.getElementById("pexplanation").innerHTML = document.getElementById("explanation").value;
    document.getElementById("psource").innerHTML = document.getElementById("source").value;

    MathJax.Hub.Typeset();
}

function update() {
    document.getElementById("json_data").value = JSON.stringify({
        name: document.getElementById("name").value,
        time_limit: document.getElementById("time_limit").value,
        memory_limit: document.getElementById("memory_limit").value,
        rating: document.getElementById("rating").value,
        description: document.getElementById("description").value,
        input: document.getElementById("input").value,
        output: document.getElementById("output").value,
        sample_cases: document.getElementById("sample_cases").value,
        explanation: document.getElementById("explanation").value,
        source: document.getElementById("source").value
    });
}

function apply() {
    document.getElementById("name").value = JSON.parse(document.getElementById("json_data").value).name;
    document.getElementById("time_limit").value = JSON.parse(document.getElementById("json_data").value).time_limit;
    document.getElementById("memory_limit").value = JSON.parse(document.getElementById("json_data").value).memory_limit;
    document.getElementById("rating").value = JSON.parse(document.getElementById("json_data").value).rating;
    document.getElementById("description").value = JSON.parse(document.getElementById("json_data").value).description;
    document.getElementById("input").value = JSON.parse(document.getElementById("json_data").value).input;
    document.getElementById("output").value = JSON.parse(document.getElementById("json_data").value).output;
    document.getElementById("sample_cases").value = JSON.parse(document.getElementById("json_data").value).sample_cases;
    document.getElementById("explanation").value = JSON.parse(document.getElementById("json_data").value).explanation;
    document.getElementById("source").value = JSON.parse(document.getElementById("json_data").value).source;
}

function copy() {
    navigator.clipboard.writeText(document.getElementById("json_data").value);
    document.getElementById("copied").innerHTML = "Copied!";
    setTimeout(() => {document.getElementById("copied").innerHTML = "Copy JSON to Clipboard";}, 1000);
}