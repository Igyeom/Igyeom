from flask import Flask, render_template, request, redirect, make_response, Response
import secrets
import json
import bcrypt
import os
import time
import subprocess
from timeit import timeit

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True

@app.route('/')
def home():
    with open("sessions.json", "r") as f:
        sessions = json.load(f)
    try:
        with open("problems.json", "r") as f:
            problems = json.load(f)
            p = {}
            for i in problems:
                p[i['problem_id']] = i['rating']
        with open("users.json", "r") as f:
            users = json.load(f)
            for i in users:
                if i['name'] == sessions[request.cookies.get('session')]:
                    username = i['name']
        
                    with open("submissions.json", "r") as f:
                        submissions = json.load(f)
                        solved = sorted([i for i in submissions if i['name'] == username and i['verdict'] == "Accepted"], key=lambda x:  int(p[x['problem_id']]), reverse=True)
                        rating = 0
                        q = []
                        for i in solved:
                            if i['problem_id'] in q: continue
                            q.append(i['problem_id'])
                            rating += int(p[i['problem_id']])
                        rating //= 10
                        if rating < 2400:
                            rating += min(600, len(solved))
                        else:
                            rating += len(solved)
                    user = [i for i in users if i['name'] == username][0]
                    r = int(rating)

                    if user['role'] == "admin":
                        return render_template('home.html', session=sessions[request.cookies.get('session')], rating="admin")
                    elif r >= 3000:
                        return render_template('home.html', session=sessions[request.cookies.get('session')], rating="gm")
                    elif r >= 2500:
                        return render_template('home.html', session=sessions[request.cookies.get('session')], rating="red")
                    elif r >= 2100:
                        return render_template('home.html', session=sessions[request.cookies.get('session')], rating="dia")
                    elif r >= 1700:
                        return render_template('home.html', session=sessions[request.cookies.get('session')], rating="plat")
                    elif r >= 1400:
                        return render_template('home.html', session=sessions[request.cookies.get('session')], rating="gold")
                    elif r >= 1000:
                        return render_template('home.html', session=sessions[request.cookies.get('session')], rating="silver")
                    elif r >= 800:
                        return render_template('home.html', session=sessions[request.cookies.get('session')], rating="bronze")
                    else:
                        return render_template('home.html', session=sessions[request.cookies.get('session')], rating="unrated")
    except KeyError:
        return render_template('home.html', session='')
    
@app.route('/@<path:username>')
def profile(username):
    with open("users.json", "r") as f:
        users = json.load(f)

    p = {}

    with open("problems.json", "r") as f:
        problems = json.load(f)
        for i in problems:
            p[i['problem_id']] = i['rating']
        
    with open("submissions.json", "r") as f:
        submissions = json.load(f)
        solved = sorted([i for i in submissions if i['name'] == username and i['verdict'] == "Accepted"], key=lambda x:  int(p[x['problem_id']]), reverse=True)
        rating = 0
        q = []
        for i in solved:
            if i['problem_id'] in q: continue
            q.append(i['problem_id'])
            rating += int(p[i['problem_id']])
        rating //= 10
        if rating < 2400:
            rating += min(600, len(solved))
        else:
            rating += len(solved)
    user = [i for i in users if i['name'] == username][0]
    r = rating
    if user['role'] == "admin":
        return render_template('profile.html', username="admin@" + username + "@", role=user['role'], rating=r, solved=q)
    elif r >= 3000:
        return render_template('profile.html', username="gm@" + username + "@", role=user['role'], rating=r, solved=q)
    elif r >= 2500:
        return render_template('profile.html', username="red@" + username + "@", role=user['role'], rating=r, solved=q)
    elif r >= 2100:
        return render_template('profile.html', username="dia@" + username + "@", role=user['role'], rating=r, solved=q)
    elif r >= 1700:
        return render_template('profile.html', username="plat@" + username + "@", role=user['role'], rating=r, solved=q)
    elif r >= 1400:
        return render_template('profile.html', username="gold@" + username + "@", role=user['role'], rating=r, solved=q)
    elif r >= 1000:
        return render_template('profile.html', username="silver@" + username + "@", role=user['role'], rating=r, solved=q)
    elif r >= 800:
        return render_template('profile.html', username="bronze@" + username + "@", role=user['role'], rating=r, solved=q)
    return render_template('profile.html', username="unrated@" + username + "@", role=user['role'], rating=r, solved=q)

@app.route('/logout')
def logout():
    with open("sessions.json", "r+") as f:
        sessions = json.load(f)
        sessions.pop(request.cookies.get('session'))
        f.seek(0)
        f.truncate(0)
        json.dump(sessions, f, indent=4)
    resp = make_response(redirect('/'))
    resp.set_cookie('session', '', expires=0)
    return resp

@app.route('/submit/<problem_id>')
def submit(problem_id):
    return render_template('submit.html', problem_id=problem_id)


@app.route('/create/<problem_id>', methods=['POST'])
def create(problem_id):
    if request.cookies.get('session') == None:
        return redirect('../login')
    
    with open("sessions.json", "r") as f:
        sessions = json.load(f)
        if sessions[request.cookies.get('session')] != "ian":
            return "You are not authorized to access this page."
    
    with open("problems.json", "r+") as f:
        problems = json.load(f)
        d = json.loads(request.form["json_data"])
        d.update({"problem_id": problem_id, "submittable": "wip", "private": True})
        problems.append(d)
        f.seek(0)
        f.truncate(0)
        json.dump(problems, f, indent=4)
    
    return "Success!"

@app.route('/process-contest/<contest_id>', methods=['POST'])
def process_contest(contest_id):
    if request.cookies.get('session') == None:
        return redirect('../login')
    
    with open("sessions.json", "r") as f:
        sessions = json.load(f)
        if sessions[request.cookies.get('session')] != "ian":
            return "You are not authorized to access this page."
        with open("contests.json", "r+") as g:
            contests = json.load(g)
            name = request.form['name']
            problems = request.form['problems'].split(",")
            scoring = request.form['scoring'].split(",")
            start_time = request.form['schedule']
            duration = request.form['duration']
            description = request.form['description']

            contests.append({"id": contest_id, "name": name, "problems": problems, "scoring": scoring, "start_time": start_time, "duration": duration, "description": description, "participants": {}, "organisers": ["ian"]})
            f.seek(0)
            f.truncate(0)
            json.dump(contests, g, indent=4)
    
    return render_template('create-contest.html', contest_id=contest_id)

@app.route('/contest/<contest_id>')
def contest(contest_id):
    with open("contests.json", "r") as f:
        contests = json.load(f)
        contest = [i for i in contests if i['id'] == contest_id][0]
    return render_template('contest.html', id=contest_id, name=contest['name'], problems=", ".join(contest['problems']), scoring=", ".join(contest['scoring']), start_time=contest['start_time'], duration=contest['duration'], description=contest['description'], participants=contest['participants'], organisers=contest['organisers'])

@app.route('/standings')
def standings():
    with open("submissions.json", "r") as f:
        submissions = json.load(f)
        participants = []
        scoring = {
            "A": 100,
            "B": 300,
            "C": 9999,
            "D": 150,
        }
        for i in submissions:
            if i['problem_id'] in "ABCD" and i['verdict'] == "Accepted":
                participants.append({'name': i['name'], i['problem_id']: scoring[i['problem_id']]})
        
        
        hitlist = []
        names = []

        for i in range(len(participants)):
            for j in range(len(participants)):
                if participants[i]['name'] == participants[j]['name']:
                    participants[i].update(participants[j])
                    participants[i]["score"] = sum(participants[i].get(problem, 0) for problem in scoring.keys())
        
        participants.sort(key=lambda x: x["score"], reverse=True)
        
        for i in participants:
            if i['name'] in names: continue
            hitlist.append(i)
            names.append(i['name'])
        

        
        for j in participants:
            for i in ["A", "B", "C", "D"]:
                if i not in j:
                    j.update({i: 0})


        return render_template('standings.html', total=len(hitlist), participants=hitlist)

@app.route('/contest/<contest_id>/register')
def register_contest(contest_id):
    with open("sessions.json", "r") as f:
        sessions = json.load(f)
        username = sessions[request.cookies.get('session')]
    
    with open("contests.json", "r+") as f:
        contests = json.load(f)
        contest = [i for i in contests if i['id'] == contest_id][0]
        if username not in contest['participants']:
            contest['participants'].update({username: []})
        f.seek(0)
        f.truncate(0)
        json.dump(contests, f, indent=4)
    
    return redirect(f'/contest/{contest_id}')

@app.route('/create-contest/<contest_id>')
def create_contest(contest_id):
    if request.cookies.get('session') == None:
        return redirect('../login')
    
    with open("sessions.json", "r") as f:
        sessions = json.load(f)
        if sessions[request.cookies.get('session')] != "ian":
            return "You are not authorized to access this page."
    
    return render_template('create-contest.html', contest_id=contest_id)

@app.route('/create-problem/<problem_id>')
def create_problem(problem_id):
    if request.cookies.get('session') == None:
        return redirect('../login')
    
    with open("sessions.json", "r") as f:
        sessions = json.load(f)
        if sessions[request.cookies.get('session')] != "ian":
            return "You are not authorized to access this page."
    
    return render_template('create-problem.html', problem_id=problem_id)

c = []

@app.route('/process/<problem_id>', methods=['POST'])
def process(problem_id):
    global c
    with open("sessions.json", "r") as f:
        sessions = json.load(f)
        username = sessions[request.cookies.get('session')]
    
    with open("problems.json", "r") as f:
        problems = json.load(f)
        time_limit = [i for i in problems if i['problem_id'] == problem_id][0]['time_limit']
    
    with open("contests.json", "r") as f:
        contests = json.load(f)
        for i in contests:
            if int(i['start_time']) <= time.time() and int(i['start_time'])+int(i['duration'])*60 > time.time() and username in i['participants']:
                c = i['problems']
    
    with open("submissions.json", "r+") as s:
        submissions = json.load(s)
        submission_id = int(submissions[-1]['id']) + 1
        while os.path.exists(f"static/data/temp_{submission_id}.py"):
            os.remove(f"static/data/temp_{submission_id}.py")
            submission_id += 1
        
        f = open(f"static/data/temp_{submission_id}.py", "x")
        f.close()
        with open(f"static/data/temp_{submission_id}.py", "r+") as f:
            f.write(request.form['source'])
        verdict = "Accepted"
        runtime = 0
        for i in sorted(os.listdir(f"test_data/{problem_id}"), key=lambda x: int(x.split(".")[0])):
            if i.endswith(".in"):
                continue
            with open(f"test_data/{problem_id}/{i[:-4]}.in", "r") as f:
                c = [f.read()]
            with open(f"test_data/{problem_id}/{i}", "r") as f:
                c.append(f.read())
            
            try:
                res2 = subprocess.run(f"python3 static/data/temp_{submission_id}.py", shell=True, input=c[0].encode('utf-8'), stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=6)
            except subprocess.TimeoutExpired:
                verdict = "Time limit exceeded (test case " + i[:-4] + ")"
                break

            res = timeit('subprocess.run(f"python3 static/data/temp_' + str(submission_id) + '.py", shell=True, input=c[0].encode(\'utf-8\'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)', setup='import subprocess', number=5, globals=globals())
            runtime = float(res)/5


            if runtime > float(time_limit):
                verdict = "Time limit exceeded (test case " + i[:-4] + ")"
                break

            #sys.stdout.write(res.stdout.decode() + "\n")
            if res2.stdout.decode().strip() != c[1].strip():
                verdict = "Wrong answer (test case " + i[:-4] + ")"
                break
                
        # if verdict == 'Accepted' and int(problem_id) in c:
        #     contest = [i for i in contests if i['problems'] == c][0]
        #     contest['participants'][username].append(c.index(int(problem_id)))
        
        os.remove(f"static/data/temp_{submission_id}.py")
        
        submissions.append({"id": submission_id, "name": username, "problem_id": problem_id, "source": request.form['source'], "verdict": verdict, "time": str(int(round(runtime*1000)))})
        s.seek(0)
        s.truncate(0)
        json.dump(submissions, s, indent=4)

    return redirect(f'/submissions/user/{username}')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/session-update', methods=['POST'])
def session_update():
    with open("users.json", "r") as f:
        users = json.load(f)
        for user in users:
            if user["name"] == request.form['username']:
                if bcrypt.checkpw(request.form['password'].encode(), user["password"].encode()):
                    with open("sessions.json", "r+") as f:
                        sessions = json.load(f)
                        token = secrets.token_urlsafe(32)
                        sessions[token] = request.form['username']
                        f.seek(0)
                        f.truncate(0)
                        json.dump(sessions, f, indent=4)
                    resp = make_response(redirect('/'))
                    resp.set_cookie('session', token)
                    return resp
    return render_template('login.html', error="Invalid username or password")

@app.route('/submissions/user/<name>')
def submissions_user(name):
    with open("submissions.json", "r") as f:
        s = json.load(f)
    s2 = [i for i in s if i['name'] == name]
    return render_template('submissions.html', name=name, submissions=s2[::-1], total=str(len(s2)))

@app.route('/submissions/problem/<problem_id>')
def submissions_problem(problem_id):
    with open("submissions.json", "r") as f:
        s = json.load(f)
    s2 = [i for i in s if i['problem_id'] == problem_id]
    return render_template('submissions.html', name="Problem #"+problem_id, submissions=s2[::-1], total=str(len(s2)))

@app.route('/problemset')
def problemset():
    with open("problems.json", "r") as f:
        problems = [i for i in json.load(f) if not i['private'] and i['problem_id'] not in "ABCD"]
    return render_template('problemset.html', problems=problems, total=str(len(problems)))

@app.route('/contests')
def contests():
    with open("contests.json", "r") as f:
        contests = json.load(f)
    return render_template('contests.html', contests=contests, total=str(len(contests)))

@app.route('/submittable')
def submittable():
    with open("problems.json", "r") as f:
        problems = [i for i in json.load(f) if i['submittable'] == 'yes']
    return render_template('problemset.html', problems=problems, total=str(len(problems)))

@app.route('/tasks')
def tasks():
    c = "ABCD"
    with open("problems.json", "r") as f:
        problems = [i for i in json.load(f) if i['problem_id'] in c]
    for i in problems:
        if len(i['name']) > 40:
            i['name'] = i['name'][:60] + "..."
    return render_template('problemset.html', problems=problems, total=str(len(problems)))

@app.route('/source/<submission_id>')
def source(submission_id):
    with open("submissions.json", "r") as f:
        s = json.load(f)
    with open("sessions.json", "r") as f:
        sessions = json.load(f)
        for i in s:
            if i['name'] == sessions[request.cookies.get('session')] or sessions[request.cookies.get('session')] == "ian":
                if str(i['id']) == submission_id:
                    submission = i['source']
                    return Response(submission, mimetype='text/plain')
    return "You are not authorized to access this page."

@app.route('/problem/<problem_id>')
def problem(problem_id):
    with open("problems.json", "r") as f:
        problems = json.load(f)
    problem = [i for i in problems if i['problem_id'] == problem_id][0]
    if problem['private']:
        if request.cookies.get('session') == None:
            return redirect('../login')
        
        with open("sessions.json", "r") as f:
            sessions = json.load(f)
            if sessions[request.cookies.get('session')] != "ian":
                return "You are not authorized to access this page."
        return render_template('problem.html', problem=problem, id=problem_id, name=problem['name'], time_limit=problem['time_limit'], memory_limit=problem['memory_limit'], rating=problem['rating'], description=problem['description'], input=problem['input'], output=problem['output'], sample_cases=problem['sample_cases'], explanation=problem['explanation'], source=problem['source'], submittable=problem['submittable'])
    
    return render_template('problem.html', problem=problem, id=problem_id, name=problem['name'], time_limit=problem['time_limit'], memory_limit=problem['memory_limit'], rating=problem['rating'], description=problem['description'], input=problem['input'], output=problem['output'], sample_cases=problem['sample_cases'], explanation=problem['explanation'], source=problem['source'], submittable=problem['submittable'])

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    else:
        user = {"name": request.form['username'], "password": bcrypt.hashpw(request.form['password'].encode(), bcrypt.gensalt()).decode(), "role": "user", "rating": "0"}
        with open("users.json", "r") as f:
            users = json.load(f)
        users.append(user)
        with open("users.json", "w") as f:
            json.dump(users, f, indent=4)
        return render_template('register.html', success="Successfully created account!\n")

app.run('127.0.0.1', 8080, debug=True)